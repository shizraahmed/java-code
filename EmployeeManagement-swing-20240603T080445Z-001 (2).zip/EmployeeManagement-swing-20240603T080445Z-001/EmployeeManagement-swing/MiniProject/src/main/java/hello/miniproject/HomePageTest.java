package hello.miniproject;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */

import hello.miniproject.HomePage;
import org.testng.Assert;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Administrator
 */
public class HomePageTest {

        public static void main(String[] args) {
                org.testng.TestNG testSuite = new org.testng.TestNG();
                @SuppressWarnings("rawtypes")
                Class[] classes = new Class[] { HomePageTest.class };
                testSuite.setTestClasses(classes);
                testSuite.run();
        }

        // TODO add test methods here.
        // The methods must be annotated with annotation @Test. For example:
        //
        // @Test
        // public void hello() {}

        @BeforeClass
        public static void setUpClass() throws Exception {
        }

        @AfterClass
        public static void tearDownClass() throws Exception {
        }

        @BeforeMethod
        public void setUpMethod() throws Exception {
        }

        @AfterMethod
        public void tearDownMethod() throws Exception {
                hp.dispose();
        }

        private HomePage hp;

        @BeforeClass
        public void setUp() {

                hp = new HomePage();

                hp.setVisible(false);
        }

        @Test
        public void testValidEmployeeData() {

                hp.getFnameField().setText("Beenish");
                hp.getLnameField().setText("");
                hp.getgenderField().setSelectedItem("Female");
                hp.getPhoneField().setText("12345678901");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();
                String expected = "Employee Data Added";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        /**
         *
         */
        @Test
        public void testEmptyFields() {

                hp.getFnameField().setText("");
                hp.getLnameField().setText("");
                hp.getgenderField().setSelectedItem("None");
                hp.getPhoneField().setText("");
                hp.getPositionField().setSelectedItem("None");
                hp.getSalaryField().setText("");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();
                String expected = "Please Fill all the fields";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidFirstname() {

                hp.getFnameField().setText("123");
                hp.getLnameField().setText("Ali");
                hp.getgenderField().setSelectedItem("Female");
                hp.getPhoneField().setText("12345678901");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Last Name or First Name cannot contain numeric values";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);

        }

        @Test
        public void testInvalidLastname() {

                hp.getFnameField().setText("John");
                hp.getLnameField().setText("1234");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("1234567890");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Last Name or First Name cannot contain numeric values";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidNames() {

                hp.getFnameField().setText("1234");
                hp.getLnameField().setText("1234");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("123456789011");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Last Name or First Name cannot contain numeric values";
                String actual = HomePage.getMessage();
                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testEmpty_Names_Field() {

                hp.getFnameField().setText("");
                hp.getLnameField().setText("");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("123456789011");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("17000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please fill the First Name Field";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testEmptyGender() {

                hp.getFnameField().setText("Baneen");
                hp.getLnameField().setText("Fatima");
                hp.getgenderField().setSelectedItem("None");
                hp.getPhoneField().setText("12345678901");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("8000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please select an option except none";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidPhone() {

                hp.getFnameField().setText("Baneen");
                hp.getLnameField().setText("Fatima");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("abc");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("5415");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Phone Field can only contain numbers or exactly 11 digits";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidSalary() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("123456789011");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("abc");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Salary Field can only contain numbers or cannot be empty";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidSalaryPhone() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("abc");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("abc");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Salary Field can only contain numbers or cannot be empty";
                String actual = HomePage.getMessage();
                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testSalaryZero() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("None");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("None");
                hp.getSalaryField().setText("0");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please enter a value greater than 0";
                String actual = HomePage.getMessage();
                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidCheckBoxes() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("None");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("None");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please select an option except none";
                String actual = HomePage.getMessage();
                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testInvalidPosition() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("None");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please select an option except none";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testEmptyFname() {

                hp.getFnameField().setText("");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please fill the First Name Field";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);

        }

        @Test
        public void testEmptyLname() {
                // Simulate entering invalid input
                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please fill the Last Name Field";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testEmptyPhoneFields() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("50000");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Phone Field can only contain numbers or exactly 11 digits";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

        @Test
        public void testEmptySalary() {

                hp.getFnameField().setText("Muniba");
                hp.getLnameField().setText("Majid");
                hp.getgenderField().setSelectedItem("Male");
                hp.getPhoneField().setText("12345678987");
                hp.getPositionField().setSelectedItem("Director");
                hp.getSalaryField().setText("");
                java.util.Date date = new java.util.Date();
                hp.getDate().setDate(date);
                hp.getAddButton().doClick();

                String expected = "Please fill the Salary Field";
                String actual = HomePage.getMessage();

                Assert.assertEquals(actual, expected);
        }

}

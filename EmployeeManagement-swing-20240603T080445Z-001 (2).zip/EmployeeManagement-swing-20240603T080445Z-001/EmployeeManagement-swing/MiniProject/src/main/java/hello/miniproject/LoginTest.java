package hello.miniproject;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    @Test
    public void testValidLogin() {
        Login login = new Login();
        login.getUsername().setText("Admin");
        login.getPassword().setText("abc");
        login.getBtn().doClick();
        // You can add assertions here to test if the login was successful
    }

    @Test
    public void testInvalidLogin() {
        Login login = new Login();
        login.getUsername().setText("Admin");
        login.getPassword().setText("wrongpassword");
        login.getBtn().doClick();
        // You can add assertions here to test if the login failed with an invalid password
    }
}

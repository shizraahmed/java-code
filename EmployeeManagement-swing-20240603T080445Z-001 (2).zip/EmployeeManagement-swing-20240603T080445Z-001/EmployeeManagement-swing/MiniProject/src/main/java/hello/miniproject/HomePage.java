package hello.miniproject;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Administrator
 */

public class HomePage extends javax.swing.JFrame {

    private JButton Button1;

    public void publicAddActionPerformed(ActionEvent evt) {
        jButton1ActionPerformed(evt);
    }

    public JTextField getFnameField() {

        return Fname;
    }

    public JTextField getLnameField() {

        return Lname;
    }

    public JTextField getPhoneField() {

        return Phone;
    }

    public JTextField getSalaryField() {
        return Salary;
    }

    public JComboBox getgenderField() {
        return Gender;
    }

    public JComboBox getPositionField() {
        return Position;
    }

    public JButton getAddButton() {
        return jButton1;
    }

    public JDateChooser getDate() {
        return jDateChooser1;
    }

    public static String message;

    private ArrayList<Employees> employeeList = new ArrayList<>();

    public static void setMessage(String Message) {
        message = Message;
    }

    public static String getMessage() {
        return message;
    }

    private boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private void saveHireDate() {
        Date hireDate = jDateChooser1.getDate(); // Get the selected date from the JDateChooser

        if (hireDate != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String hireDateString = dateFormat.format(hireDate);

            // Now you can use the hireDateString or hireDate as needed
            System.out.println("Hire Date: " + hireDateString);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a valid date.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Component HomePage;

    /**
     * Creates new form HomePage
     */
    public HomePage() {
        initComponents();

    }

    public HomePage(ArrayList emp) {
        initComponents();
        employeeList.addAll(emp);
        DefaultTableModel model3 = (DefaultTableModel) jTable1.getModel();

        // Clear the table before populating it to avoid duplicates
        model3.setRowCount(0);

        for (Employees employee : employeeList) {
            Object[] rowData = { employee.getEmpid(), employee.getFname(), employee.getLname(), employee.getGender(),
                    employee.getPhone(), employee.getPosition(), employee.getSalary(), employee.getHiredate() };
            model3.addRow(rowData);
        }

    }
    // initializes the gui components
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        scrollPane1 = new java.awt.ScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        Fname = new javax.swing.JTextField();
        Lname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        Phone = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Salary = new javax.swing.JTextField();
        Position = new javax.swing.JComboBox<>();
        Edit = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Home Page");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel10.setText("Welcome Admin ! ");

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-office-48.png")); // NOI18N
        jButton2.setText("Search Records");
        jButton2.setBorder(null);
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-logout-60 (1).png")); // NOI18N
        jButton3.setText("Logout");
        jButton3.setBorder(null);
        jButton3.setIconTextGap(10);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-user-100 (2) (1).png")); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 22, Short.MAX_VALUE)
                        .addComponent(jLabel10)
                        .addGap(20, 20, 20))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee Id", "First Name", "Last Name", "Gender", "Phone Number", "Position", "Salary", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        scrollPane1.add(jScrollPane1);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("First Name:");

        Fname.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        Lname.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Last Name:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("Gender");

        Gender.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Male", "Female", "Prefer Not to Say" }));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Phone Number:");

        Phone.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel7.setText("Position:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel8.setText("Salary:");

        Salary.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Salary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalaryActionPerformed(evt);
            }
        });

        Position.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Position.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Director", "Assistant Director", "Senior Manager", "Junior Manager", "Assistant Manager", "Higher Staff", "Lower Staff" }));

        Edit.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Edit.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-edit-24.png")); // NOI18N
        Edit.setText("Edit");
        Edit.setIconTextGap(10);
        Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditActionPerformed(evt);
            }
        });

        Delete.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-delete-24.png")); // NOI18N
        Delete.setText("Delete");
        Delete.setIconTextGap(10);
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-add-24 (1).png")); // NOI18N
        jButton1.setText("Add");
        jButton1.setIconTextGap(10);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\pc\\Downloads\\EmployeeManagement-swing-20240603T080445Z-001\\EmployeeManagement-swing\\MiniProject\\src\\main\\java\\Images\\icons8-employee-50.png")); // NOI18N
        jLabel1.setText("Employee Data");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel11.setText("Hire Date");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 24, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Fname, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Lname, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Gender, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Phone, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Position, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Phone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(Fname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(Lname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(220, 220, 220))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalaryActionPerformed
        // TODO add your handling code here:
        
        
     
    }//GEN-LAST:event_SalaryActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model1 = (DefaultTableModel) jTable1.getModel();
        int count = 0;
jDateChooser1.setDateFormatString("yyyy-MM-dd");
        if (!Salary.getText().equals("")) {
            String salary = Salary.getText();
            if (salary.matches("\\d+")) {
                count = Integer.parseInt(salary);
                Date selectedDate = jDateChooser1.getDate(); // Get the selected date

    if (selectedDate != null) {
        // Format the selected date as needed
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String hireDate = dateFormat.format(selectedDate);

                if (!Gender.getSelectedItem().equals("None") && !Position.getSelectedItem().equals("None") && count > 0
                        && Phone.getText().matches("^\\d{11}$") && !Fname.getText().equals("")
                        && !Lname.getText().equals("") && !Fname.getText().matches("\\d*")&& !Lname.getText().matches("\\d*")&&!Phone.getText().equals("")
                        && !Salary.getText().equals("")) {
                    String ob = (String) Gender.getSelectedItem();
                    Employees employee;

                    if ("Manager".equals(Position.getSelectedItem().toString())) {
                        employee = new Manager(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    } else if ("Assistant Director".equals(Position.getSelectedItem().toString())) {
                        employee = new AssistantDirector(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary),Position.getSelectedItem().toString(),hireDate);
                    } else if ("Director".equals(Position.getSelectedItem().toString())) {
                        employee = new Director(Fname.getText(), Lname.getText(), ob, Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    } 
                    else if ("Senior Manager".equals(Position.getSelectedItem().toString())) {
                        employee = new seniorManager(Fname.getText(), Lname.getText(), ob, Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    } 
                    else if ("Junior Manager".equals(Position.getSelectedItem().toString())) {
                        employee = new JuniorManager(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    }
                    else if ("Higher Staff".equals(Position.getSelectedItem().toString())) {
                        employee = new HigherStaff(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    } 
                    else if ("Lower Staff".equals(Position.getSelectedItem().toString())) {
                        employee = new LowerStaff(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary), Position.getSelectedItem().toString(),hireDate);
                    }
                    else if ("Assistant Manager".equals(Position.getSelectedItem().toString())) {
                        employee = new AssistantManager(Fname.getText(), Lname.getText(), ob,  Phone.getText(), Integer.parseInt(salary),Position.getSelectedItem().toString(),hireDate);
                    }
                    else {
                        // Handle other positions if needed
                        employee = null;
                    }

                    if (employee != null) {
                        employeeList.add(employee);
                   
    

                        model1.addRow(new Object[]{employee.getEmpid(), Fname.getText(), Lname.getText(),Gender.getSelectedItem(), Phone.getText(), Position.getSelectedItem(),
                                salary,hireDate});
                        
                        JOptionPane.showMessageDialog(null, "Employee Data Added", "Added", JOptionPane.INFORMATION_MESSAGE);
  
  Lname.setText("");
  Fname.setText("");
  Phone.setText("");
  Salary.setText("");
  Position.setSelectedItem("None");
  Gender.setSelectedItem("None");
  
                    } 
                    
                } else {
               
                if (Fname.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Please fill the First Name Field", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } 
                
else if (Lname.getText().matches("\\d+")||Fname.getText().matches("\\d+") || (Fname.getText().matches("\\d*") &&Lname.getText().matches("\\d*")) ){
    JOptionPane.showMessageDialog(null, "Last Name or First Name cannot contain numeric values", "Error",
            JOptionPane.ERROR_MESSAGE);}

    else if (Lname.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Please fill the Last Name Field", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else if (!Phone.getText().matches("\\d*") ||!Phone.getText().matches("^\\d{11}$") ) {
                    JOptionPane.showMessageDialog(null, "Phone Field can only contain numbers or exactly 11 digits", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else if (!Salary.getText().matches("\\d*")) {
                    JOptionPane.showMessageDialog(null, "Salary Field can only contain numbers", "Error",
                            JOptionPane.ERROR_MESSAGE);
                
                } else if (count <= 0) {
                    JOptionPane.showMessageDialog(null, "Please enter a value greater than 0", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else if (Position.getSelectedItem().equals("None") || Gender.getSelectedItem().equals("None")) {
                    JOptionPane.showMessageDialog(null, "Please select an option except none", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } else if (Gender.getSelectedItem().equals("None")&& Position.getSelectedItem().equals("None")) {
                    JOptionPane.showMessageDialog(null, "Please select an option except none", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } 
                
                else {
                    JOptionPane.showMessageDialog(null, "Please fill all the fields", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } 
   
    else {
                JOptionPane.showMessageDialog(null, "Please select date", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Salary Field can only contain numbers", "Error", JOptionPane.ERROR_MESSAGE);
        }
            
    } 
       else {
        JOptionPane.showMessageDialog(null, "Please Fill all the fields", "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    int[] selectedRows = jTable1.getSelectedRows();

    if (selectedRows.length > 0) {
        ArrayList<Integer> delIndexes = new ArrayList<>();

        for (int selectedRow : selectedRows) {
            int empIdToDelete = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
            delIndexes.add(selectedRow); // Store the indexes to delete
        }

        // Delete selected rows from the table
        for (int i = selectedRows.length - 1; i >= 0; i--) {
            model.removeRow(selectedRows[i]);
        }

        // Remove corresponding employees from the employeeList
        for (int i = delIndexes.size() - 1; i >= 0; i--) {
            int indexToRemove = delIndexes.get(i);
            employeeList.remove(indexToRemove);
        }

        JOptionPane.showMessageDialog(this, "Selected employee(s) deleted successfully.", "Delete", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Please select employee(s) to delete.", "Delete", JOptionPane.WARNING_MESSAGE);
    }



    }//GEN-LAST:event_DeleteActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
         @SuppressWarnings("unused")
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int row=jTable1.getSelectedRow();
        String date=jTable1.getValueAt(row, 7).toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = null;
    try {
        date1 = dateFormat.parse(date);
    } catch (ParseException ex) {
        Logger.getLogger(HomePage.class.getName()).log(Level.SEVERE, null, ex);
    }
          
            Fname.setText(jTable1.getValueAt(row, 1).toString());
            Lname.setText(jTable1.getValueAt(row, 2).toString());
            Gender.setSelectedItem(jTable1.getValueAt(row, 3).toString());
            Phone.setText(jTable1.getValueAt(row, 4).toString());
            Position.setSelectedItem(jTable1.getValueAt(row, 5).toString());
             Salary.setText(jTable1.getValueAt(row, 6).toString());
             jDateChooser1.setDate(date1);
            
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
        // TODO add your handling code here:
       @SuppressWarnings("unused")
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
int row = jTable1.getSelectedRow();
jDateChooser1.setDateFormatString("yyyy-MM-dd");
 Date selectedDate = jDateChooser1.getDate();
String fname = Fname.getText();
String lname = Lname.getText();
String gender = Gender.getSelectedItem().toString();
String phone = Phone.getText();
String position = Position.getSelectedItem().toString();
String salaryText = Salary.getText();
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String hireDate = dateFormat.format(selectedDate);


// Validate the input fields
if (fname.isEmpty() || lname.isEmpty() || phone.isEmpty() || salaryText.isEmpty() || gender.equals("None") || position.equals("None")) {
    JOptionPane.showMessageDialog(null, "Please fill in all the required fields.", "Error", JOptionPane.ERROR_MESSAGE);
} else if (!salaryText.matches("\\d+")) {
    JOptionPane.showMessageDialog(null, "Invalid input for Salary. Salary must be a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
} else if (!phone.matches("^\\d{11}$")) {
    JOptionPane.showMessageDialog(null, "Phone number must be exactly 11 digits.", "Error", JOptionPane.ERROR_MESSAGE);
} else if (isNumeric(fname) || isNumeric(lname)) {
    JOptionPane.showMessageDialog(null, "First Name or Last Name cannot contain numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
} else {
   
    jTable1.setValueAt(fname, row, 1);
    jTable1.setValueAt(lname, row, 2);
    jTable1.setValueAt(gender, row, 3);
    jTable1.setValueAt(phone, row, 4);
    jTable1.setValueAt(position, row, 5);
    jTable1.setValueAt(salaryText, row, 6);
    jTable1.setValueAt(hireDate, row, 7);

    Employees employee = employeeList.get(row);
    employee.setFname(fname);
    employee.setLname(lname);
    employee.setGender(gender);
    employee.setPhone(phone);
    employee.setPosition(position);
    employee.setSalary(Integer.parseInt(salaryText));
    employee.setHiredate(hireDate);

    JOptionPane.showMessageDialog(null, "Employee Data Updated Successfully", "Updated", JOptionPane.INFORMATION_MESSAGE);

    
    Lname.setText("");
    Fname.setText("");
    Phone.setText("");
    Salary.setText("");
    Position.setSelectedItem("None");
    Gender.setSelectedItem("None");
}
    }//GEN-LAST:event_EditActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Logout l1=new Logout();
        dispose();
        l1.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:\
         Screen2 s2=new Screen2(employeeList);
         dispose();
        s2.setVisible(true);
        
        
      
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 
                new HomePage().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Delete;
    private javax.swing.JButton Edit;
    private javax.swing.JTextField Fname;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JTextField Lname;
    private javax.swing.JTextField Phone;
    private javax.swing.JComboBox<String> Position;
    private javax.swing.JTextField Salary;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    @SuppressWarnings("unused")
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private java.awt.ScrollPane scrollPane1;
    // End of variables declaration//GEN-END:variables

	
}

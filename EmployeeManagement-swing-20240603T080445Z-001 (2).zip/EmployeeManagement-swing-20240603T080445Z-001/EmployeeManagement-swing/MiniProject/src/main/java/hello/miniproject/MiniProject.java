/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package hello.miniproject;

import java.util.Date;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class MiniProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
    }
}
class EmployeeIdGenerator {
    private static EmployeeIdGenerator instance;
    private int lastAssignedId = 0;

    private EmployeeIdGenerator() {
       
    }

    public static synchronized EmployeeIdGenerator getInstance() {
        if (instance == null) {
            instance = new EmployeeIdGenerator();
        }
        return instance;
    }

    public int generateId() {
        return ++lastAssignedId;
    }
}
class Employees{
    String Fname,lname,gender;
    int salary;
    String phone;
   private int empid;
   String hiredate;
String Position;
    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }

    public String getFname() {
        return Fname;
    }

    public String getLname() {
        return lname;
    }

    public String getGender() {
        return gender;
    }

    public String getPhone() {
        return phone;
    }

    public int getSalary() {
        return salary;
    }

    public String getPosition() {
        return Position;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }

    public int getEmpid() {
        return empid;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public Employees(String fname, String lname, String gender, String phone,int salary,String hiredate) {
        Fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.empid = EmployeeIdGenerator.getInstance().generateId();
        this.phone = phone;
        this.salary = salary;
        this.hiredate=hiredate;
    }

   
}
class AssistantDirector extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }

    public void setPosition(String Position) {
        this.Position = Position;
    }

    public String getPosition() {
        return Position;
    }

     public AssistantDirector(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
    }

    public AssistantDirector(String fname, String lname, String gender, String phone, int salary,String position,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }
}
class AssistantManager extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
   
public String getPosition() {
        return Position;
    }
    public void setPosition(String Position) {
        this.Position = Position;
    }
     public AssistantManager(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
    }

    public AssistantManager(String fname, String lname, String gender, String phone, int salary,String position,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }

   
}
class Manager extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }
public String getPosition() {
        return Position;
    }

    public Manager(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
    }

    public Manager(String fname, String lname, String gender, String phone, int salary,String position,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }

   
}

class seniorManager extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }public String getPosition() {
        return Position;
    }

    public seniorManager(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender,  phone, salary, hiredate);
    }

    public seniorManager(String fname, String lname, String gender,  String phone, int salary, String position,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }
}
class JuniorManager extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }public String getPosition() {
        return Position;
    }

    public JuniorManager(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
    }

    public JuniorManager(String fname, String lname, String gender,  String phone, int salary, String position,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }
}
class HigherStaff extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }
public String getPosition() {
        return Position;
    }

    public HigherStaff(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender, phone, salary,hiredate);
    }

    public HigherStaff(String fname, String lname, String gender, String phone, int salary, String position,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }
}
class LowerStaff extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
    }
public String getPosition() {
        return Position;
    }
    public LowerStaff(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
    }

    public LowerStaff(String fname, String lname, String gender,  String phone, int salary, String position,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }
}
class Director extends Employees{
    String Position;
     String hiredate;

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
public void setPosition(String Position) {
        this.Position = Position;
         
    }public String getPosition() {
        return Position;
    }

    

    public Director(String fname, String lname, String gender,  String phone, int salary,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
    }
    
    public Director(String fname, String lname, String gender,  String phone, int salary,String position,String hiredate) {
        super(fname, lname, gender,  phone, salary,hiredate);
        Position = position;
        this.hiredate = hiredate;
    }

   
}

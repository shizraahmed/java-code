
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class Screen2Test {

    // Test case for initializing the form
    @Test
    public void testFormInitialization() {
        Screen2 screen2 = new Screen2();
        assertNotNull(screen2);
    }

    // Test case for searching an existing employee
    @Test
    public void testSearchForExistingEmployee() {
        // Create a list of employees for testing
        ArrayList<Employees> employeeList = new ArrayList<>();
        Employees emp1 = new Employees("1", "John", "Doe", "Male", 50000, "2024-06-06");
        Employees emp2 = new Employees("2", "Jane", "Doe", "Female", 60000, "2024-06-07");
        employeeList.add(emp1);
        employeeList.add(emp2);

        Screen2 screen2 = new Screen2(employeeList);

        // Simulate a search for an existing employee
        screen2.jTextField1.setText("1");
        screen2.jTextField1ActionPerformed(null);

        // Check if the employee was found
        assertEquals(1, screen2.table.getSelectedRow());
    }

    // Test case for searching a non-existing employee
    @Test
    public void testSearchForNonExistentEmployee() {
        // Create a list of employees for testing
        ArrayList<Employees> employeeList = new ArrayList<>();
        Employees emp1 = new Employees("1", "John", "Doe", "Male", 50000, "2024-06-06");
        Employees emp2 = new Employees("2", "Jane", "Doe", "Female", 60000, "2024-06-07");
        employeeList.add(emp1);
        employeeList.add(emp2);

        Screen2 screen2 = new Screen2(employeeList);

        // Simulate a search for a non-existing employee
        screen2.jTextField1.setText("3"); // Assuming there's no employee with ID 3
        screen2.jTextField1ActionPerformed(null);

        // Check if no employee was found
        assertEquals(-1, screen2.table.getSelectedRow());
    }
}
